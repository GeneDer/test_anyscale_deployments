from .gauge import NDIFGauge
